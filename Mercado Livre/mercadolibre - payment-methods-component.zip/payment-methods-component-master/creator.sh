grunt build --country=ar --size=default
grunt build --country=br --size=default
grunt build --country=cl --size=default
grunt build --country=co --size=default
grunt build --country=mx --size=default
grunt build --country=ve --size=default
grunt build --country=pe --size=default

grunt build --country=ar --size=large
grunt build --country=br --size=large
grunt build --country=cl --size=large
grunt build --country=co --size=large
grunt build --country=mx --size=large
grunt build --country=ve --size=large
grunt build --country=pe --size=large

grunt build --country=ar --size=default,large
grunt build --country=br --size=default,large
grunt build --country=cl --size=default,large
grunt build --country=co --size=default,large
grunt build --country=mx --size=default,large
grunt build --country=ve --size=default,large
grunt build --country=pe --size=default,large

grunt dist

grunt images --country=ar
grunt images --country=br
grunt images --country=cl
grunt images --country=co
grunt images --country=mx
grunt images --country=ve
grunt images --country=pe
