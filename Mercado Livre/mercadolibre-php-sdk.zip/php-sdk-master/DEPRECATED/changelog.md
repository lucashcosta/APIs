MeliPHP Unofficial MercadoLibre PHP SDK (v.0.0.4)
==========================
New version with complex responses:
- Now the API responses are arrays with "body", "json", "headers" and "statusCode"
- SDK have tests!!! Now you can modify the SDK with less risk of breaking things
- Support for refresh token

MeliPHP Unofficial MercadoLibre PHP SDK (v.0.0.3)
==========================
General refactor

MeliPHP Unofficial MercadoLibre PHP SDK (v.0.0.2)
==========================
General refactor

MeliPHP Unofficial MercadoLibre PHP SDK (v.0.0.1)
==========================
First release

