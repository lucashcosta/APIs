package com.mercadolibre.sdk;

public class MeliException extends Exception {
    public MeliException(Throwable cause) {
	super(cause);
    }

    private static final long serialVersionUID = 7263275678852231779L;
}
