Mercadolibre.js Unofficial MercadoLibre Javascript SDK (v.1.0.2)
==========================
Fix bug in IE8 to bypass cross-window postMessage limitation

Mercadolibre.js Unofficial MercadoLibre Javascript SDK (v.1.0.1)
==========================
First release

