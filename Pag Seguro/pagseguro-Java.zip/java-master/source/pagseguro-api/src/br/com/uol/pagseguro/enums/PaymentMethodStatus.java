package br.com.uol.pagseguro.enums;

public enum PaymentMethodStatus {

    AVAILABLE,

    UNAVAILABLE

}
