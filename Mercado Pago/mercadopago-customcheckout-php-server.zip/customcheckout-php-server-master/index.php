<?php
// Error reporting for testing purposes
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-type: application/json");

// Autoload dependencies
require('./vendor/autoload.php');

$GLOBALS["config"] = parse_ini_file(dirname(__FILE__)."/config.ini", true);
$GLOBALS["mapping"] = parse_ini_file(dirname(__FILE__)."/mapping.ini", true);

// Handle request
function handle($data, $params) {
	$uri = parse_url ($_SERVER["REQUEST_URI"], PHP_URL_PATH);

	if (isset ($GLOBALS["config"]["server"]["base"])) {
		$uri = preg_replace("/".addcslashes($GLOBALS["config"]["server"]["base"], "/-")."/", "", $uri);
	}

	if (array_key_exists($uri, $GLOBALS["mapping"])) {
		$mapping = $GLOBALS["mapping"][$uri];

		$handler = null;
		if (array_key_exists("ALL", $mapping)) {
			$handler = $mapping["ALL"];
		} else if (array_key_exists($_SERVER["REQUEST_METHOD"], $mapping)) {
			$handler = $mapping[$_SERVER["REQUEST_METHOD"]];
		} else {
			return array(
				"status" => "405",
				"response" => array(
					"error" => "Unsupported method"
				)
			);
		}

		if ($handler) {
			try {
				$handler = explode(".", $handler);
				
				$controller = $handler[0];
				$method = $handler[1];

				require_once("./".$controller.".class.php");

				if (!isset ($$controller)) {
					$$controller = new $controller;
				}

				return $$controller->$method ($params, $data);
			} catch (Exception $e) {
				return array(
					"status" => 500,
					"response" => array(
						"error" => $e->getMessage()
					)
				);
			}
		}
	}

	return array(
		"status" => 404,
		"response" => array(
			"error" => "Not found"
		)
	);
}

// Get body as JSON
$data = file_get_contents('php://input');
$data = json_decode($data, true);

// Call request handler
$result = handle($data, $_REQUEST);

// Process errors
if (isset ($result["response"])) {
	$protocol = (isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0');
	$code = (isset($result["status"]) ? $result["status"] : 500);
	
	header("Content-type: application/json", true, intval($code));
	echo (json_encode($result["response"]));
} else {
	header("Content-type: application/json", true, 500);
}

// Process response