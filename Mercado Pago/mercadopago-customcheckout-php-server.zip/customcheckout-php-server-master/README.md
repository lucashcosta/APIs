# PHP ServerSide example

## Handles payments and customers for Custom Checkout

### Install

1. Download and run `composer update`
2. Replace your `ACCESS_TOKEN` in `CheckoutController.class.php`

## cURL example

```
curl -X POST 'http://www.server.com/checkout/examples/test/doPayment' -H 'Content-type: application/json' -d '{
    "campaign_id": null,
    "card_issuer_id": 3,
    "card_token": "9e9099ff9c16e2377458ea827e205409",
    "installments": 1,
    "item": {
        "category_id": null,
        "description": null,
        "id": "id1",
        "picture_url": null,
        "quantity": 1,
        "title": null,
        "unit_price": 100
    },
    "merchant_access_token": "mla-cards-data",
    "payment_method_id": "master"
}'
```
