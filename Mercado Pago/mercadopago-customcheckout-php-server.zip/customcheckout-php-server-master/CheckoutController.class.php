<?php
class CheckoutController {
	private $mp;

	const SAVE_CARDS = true;

	function __construct() {
		/*
		Instantiate the SDK using your private access token.
		*/
		$this->mp = new MP("ACCESS_TOKEN");
	}

	/*
	This method receives the JSON $data (body)  and the QueryString $params as associative arrays
	*/
	public function doPayment($params, $data) {
		try {
			/*
			Here you can validate that the customer is the expected one.
			As a suggestion, we're using a variable called "merchant_access_token"
			*/
			if (!isset ($data["merchant_access_token"])) {
				return array(
					"status" => 400,
					"response" => array(
						"message" => "merchant_access_token is required",
						 "error" => "bad_request",
						 "status" => 400
					 )
				);
			}

			/*
			Here you could get customer´s saved information identified by $data["merchant_access_token"]
			This information should contains customer email, and any other data you need.
			As an example we've defined a basic structure in order to use it later.
			*/
			$merchant_data = array(
				"customer" => array(
					"email" => "email@yourcustomer.com"
				)
			);

			/*
			You must send information about the item being paid.
			*/
			if (!isset ($data["item"])) {
				return array(
					"status" => 400,
					"response" => array(
						"message" => "item is required",
						 "error" => "bad_request",
						 "status" => 400
					 )
				);
			}


			/*

			Here you should validate that the item is a valid one.
			For example, you can match $data["item"]["id"] to your database
			and check that $data["item"]["unit_price"] matches the expected value,
			or validate your stock against $data["item"]["quantity"].
			
			*/

			/*
			Here you build the payment data according to the $data received from your customer.
			*/
			$payment_data = array(
				"description" => $data["item"]["description"],
				"installments" => $data["installments"] ? intval($data["installments"]) : null,
				"issuer_id" => $data["card_issuer_id"] && $data["card_issuer_id"] > 0 ? intval($data["card_issuer_id"]) : null,
				"payment_method_id" => $data["payment_method_id"],
				"additional_info" => array(
					"items" => array($data["item"])
				),
				"transaction_amount" => floatval($data["item"]["unit_price"]) * intval($data["item"]["quantity"]),
				/* Here we use the customer email we obtained at the begining */
				"payer" => array(
					"email" => $merchant_data["customer"]["email"]
				)
			);

			if ($data["card_token"]){
				$payment_data["token"] = $data["card_token"];
			}

			/*
			Send the payment information to the API using MP PHP SDK
			*/
			$result = $this->mp->post(array(
				"uri" => "/v1/payments", 
				"data" => $payment_data
			));

			if ($result["status"] == 201) {

				$created_payment = $result["response"];
				/*
				Here your payment was created successfully.
				You can do anything you want now, like release the product, update your stock, or any other action.
				*/


				/*
				You can save the card sent by your client in order to reuse it again as a suggestion.
				Associate card to customer based on SAVE_CARDS variable value. You can override this 
				value to false if you do not want to create customers + cards.
				*/
				if (self::SAVE_CARDS) {
					$card_saved = false;

					/*
					First, get the customer information.
					*/
					$customer = $this->getCustomer(array("merchant_access_token" => $data["merchant_access_token"]));

					/*
					If the customer exists, add the new card to that customer.
					*/
					if ($customer["status"] == 200) {
						$card_saved = $this->mp->post(array(
							"uri" => "/v1/customers/".$customer["response"]["id"]."/cards",
							"data" => array(
								"token" => $data["card_token"]
							)
						));
					} else if ($customer["status"] == 404) {
						/*
						Else, create the customer with the associated card.
						*/
						$card_saved = $this->mp->post(array(
							"uri" => "/v1/customers",
							"data" => array(
								"email" => $merchant_data["customer"]["email"],
								"token" => $data["card_token"]
							)
						));
					} else {
						/*
						Error getting customer
						*/
					}

					/*
					Set a successful flag in the response to know if the customer / card was saved ok.
					*/
					$result["response"]["card_saved"] = $card_saved && in_array($card_saved["status"],  array(200, 201));
				}

				/*
				Fix empty metadata due to a json-php conversion issue
				*/
				if (isset ($result["response"]["metadata"]) && count($result["response"]["metadata"]) == 0) {
					$result["response"]["metadata"] = new stdClass;
				}
			} else {
				/*
				Your payment was not created due to an error.
				Here you can take actions according to the error code, for example ask your user to retry, or to correct the wrong data.
				*/
			}

			return $result;

		} catch(MercadoPagoException $e) {
			/*
			If something unexpected happened, return a structure similar to the one that returns the SDK, with details of the error.
			*/
			return array(
				"status" => $e->getCode(),
				"response" => array(
					"error" => "mercadopago",
					"message" => $e->getMessage()
				)
			);
		} catch (Exception $e) {
			/*
			If something unexpected happened, return a structure similar to the one that returns the SDK, with details of the error.
			*/

			return array(
				"status" => 500,
				"response" => array(
					"error" => "internal_error",
					"message" => $e->getMessage()
				)
			);
		}
	}

	/*
	This method receives the JSON $data (body)  and the QueryString $params as associative arrays
	*/
	public function getCustomer($params) {
		try {
			/*
			Here you can validate that the customer is the expected one.
			As a suggestion, we're using a variable called "merchant_access_token"
			Due to this method responds to a GET request, we will read the value from $params instead $data.
			*/
			if (!isset ($params["merchant_access_token"])) {
				return array(
					"status" => 400,
					"response" => array(
						"message" => "merchant_access_token is required",
						 "error" => "bad_request",
						 "status" => 400
					 )
				);
			}

			/*
			Here you could get customer´s saved information identified by $data["merchant_access_token"]
			This information should contains customer email, and any other data you need.
			As an example we've defined a basic structure in order to use it later.
			*/
			$merchant_data = array(
				"customer" => array(
					"email" => "email@yourcustomer.com"
				)
			);

			/*
			Now you can get the associated customer according to the email you obtained from your merchant data.
			*/
			$result = $this->mp->get(array(
				"uri" => "/v1/customers/search",
				"params" => array("email" => $merchant_data["customer"]["email"])
			));

			if ($result["status"] == 200) {
				/*
				Validate that one (and just one) customer was returned.
				*/
				$customer = $result["response"]["paging"]["total"] == 1 ? $result["response"]["results"][0] : null;

				$result["response"] = $customer;
			}

			return $result;

		} catch(MercadoPagoException $e) {
			/*
			If something unexpected happened, return a structure similar to the one that returns the SDK, with details of the error.
			*/
			return array(
				"status" => $e->getCode(),
				"response" => array(
					"error" => "mercadopago",
					"message" => $e->getMessage()
				)
			);
		} catch(Exception $e) {
			/*
			If something unexpected happened, return a structure similar to the one that returns the SDK, with details of the error.
			*/
			return array(
				"status" => 500,
				"response" => array(
					"error" => "internal_error",
					"message" => $e->getMessage()
				)
			);
		}
	}
}
