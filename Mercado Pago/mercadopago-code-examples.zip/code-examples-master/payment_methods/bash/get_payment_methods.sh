curl -X GET \
-H "accept: application/json" \
"https://api.mercadopago.com/v1/payment_methods" \
-d "access_token=ACCESS_TOKEN"