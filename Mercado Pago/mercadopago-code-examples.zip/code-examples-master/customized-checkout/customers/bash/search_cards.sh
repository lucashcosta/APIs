curl -X GET \
        -H 'accept: application/json' \
        'https://api.mercadopago.com/v1/customers/[CUSTOMER_ID]/cards?access_token=ACCESS_TOKEN'