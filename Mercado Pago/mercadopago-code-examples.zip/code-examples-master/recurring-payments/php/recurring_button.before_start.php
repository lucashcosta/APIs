<!DOCTYPE html>
<html>
	<head>
		<title>Subscribe</title>
	</head>
	<body>
		<a href="subscription_link">Subscribe</a>
	</body>
</html>