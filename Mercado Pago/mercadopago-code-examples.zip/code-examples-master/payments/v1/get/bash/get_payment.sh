curl -G -X GET \
-H "accept: application/json" \
"https://api.mercadopago.com/v1/payments/[ID]" \
-d "access_token=ACCESS_TOKEN"