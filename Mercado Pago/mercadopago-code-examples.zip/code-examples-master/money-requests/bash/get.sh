curl -X GET \
-H 'accept: application/json' \
'https://api.mercadopago.com/money_requests/:ID?access_token=ACCESS_TOKEN'