//
//  MPResultViewController.h
//  MercadoPagoMobile
//
//  Created by jgyonzo on 5/8/14.
//  Copyright (c) 2014 MercadoPago. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPResultViewController : UIViewController

- (void) setResultInfo: (NSString *) info;

@end
